using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Social")]
	public class ISN_ShareScreeenShot : FsmStateAction {

		public FsmString message;
		public FsmTexture texture;
		
		public override void OnEnter() {
			
			ISN_ScreehSotPostTask task  = new GameObject("ScreehSotPostTask").AddComponent<ISN_ScreehSotPostTask>();
			task.type = "M";
			task.msg = message.Value;
			
		}
		
		public override void Reset() {
			base.Reset();
			message   = "Message Text";
			
		}

	}
}


