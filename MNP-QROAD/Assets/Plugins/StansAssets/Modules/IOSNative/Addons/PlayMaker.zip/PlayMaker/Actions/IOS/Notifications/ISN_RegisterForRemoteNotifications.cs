﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_RegisterForRemoteNotifications : FsmStateAction {

		public FsmString deviceToken;

		#if UNITY_IPHONE
		public UnityEngine.iOS.RemoteNotification type;
		#endif
	
		public override void OnEnter() {
			#if UNITY_IPHONE

			ISN_RemoteNotificationsController.Instance.RegisterForRemoteNotifications(OnDeviceTokenReceived);
		
			#endif
		}

		private void OnDeviceTokenReceived(ISN_RemoteNotificationsRegistrationResult result) {
			#if UNITY_IPHONE

		
			deviceToken = result.Token.TokenString;
			Finish ();
			#endif
		}
	}
}





