﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Aaction will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class ISN_PurchaseAction : FsmStateAction {


		[Tooltip("Event fired when Store Kit purchase is deferred")]
		public FsmEvent deferredEvent;

		[Tooltip("Event fired when Store Kit purchase is complete")]
		public FsmEvent purchasedEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;


		[Tooltip("Purhase product Id")]
		public string ProductID  = "";


		[UIHint(UIHint.Variable)]
		public FsmString receipt;

		

		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);

		}

		private void OnBillingInit() {
			Debug.Log ("DEBUG: PURCHASE ACTION " + ProductID);
			IOSInAppPurchaseManager.OnTransactionComplete += OnTransactionComplete;
			IOSInAppPurchaseManager.Instance.BuyProduct(ProductID);
		}

		void OnTransactionComplete (IOSStoreKitResult resp) {
			Debug.Log ("DEBUG: OnTransactionComplete");
			if(!resp.ProductIdentifier.Equals(ProductID)) {
				return;
			}

			IOSInAppPurchaseManager.OnTransactionComplete -= OnTransactionComplete;
			Debug.Log ("STATE = " + resp.State.ToString());
			switch(resp.State) {
			case InAppPurchaseState.Purchased:
			case InAppPurchaseState.Restored:
				receipt.Value = resp.Receipt;
				Fsm.Event(purchasedEvent);
				break;
			case InAppPurchaseState.Deferred:
				Fsm.Event(deferredEvent);
				break;
			case InAppPurchaseState.Failed:
				Fsm.Event(failEvent);
				break;
			}

			Finish();
		}

		
	}
}
