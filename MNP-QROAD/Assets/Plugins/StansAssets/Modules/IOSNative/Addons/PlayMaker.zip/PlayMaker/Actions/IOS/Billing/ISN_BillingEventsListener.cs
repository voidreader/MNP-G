using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Init billing. Best practice to do this on appplicaton start")]
	public class ISN_BillingEventsListener : FsmStateAction {




		public FsmEvent InitCompleteEvent;
		public FsmEvent RestoreProductsCompleteEvent;



		public FsmString TransactionProductId;
		public FsmEvent ProductPurchasedEvent;
		public FsmEvent ProductRestoredEvent;
		public FsmEvent PurchaseFailedEvent;
		public FsmEvent PurchaseDeferredEvent;




		public override void OnEnter() {



			IOSInAppPurchaseManager.OnTransactionComplete -= OnTransactionComplete;
			IOSInAppPurchaseManager.OnRestoreComplete -= OnRestoreComplete;
			IOSInAppPurchaseManager.OnStoreKitInitComplete -= OnStoreKitInitComplete;

			IOSInAppPurchaseManager.OnTransactionComplete += OnTransactionComplete;
			IOSInAppPurchaseManager.OnRestoreComplete += OnRestoreComplete;
			IOSInAppPurchaseManager.OnStoreKitInitComplete += OnStoreKitInitComplete;



		}



		public void OnStoreKitInitComplete (SA.Common.Models.Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(InitCompleteEvent);

			}
		}


		public void OnRestoreComplete (SA.Common.Models.Result res) {
			if(res.IsSucceeded) {
				Fsm.Event(RestoreProductsCompleteEvent);
			}
		}

		public void OnTransactionComplete (IOSStoreKitResult res) {
			TransactionProductId.Value = res.ProductIdentifier;

			switch(res.State) {
				case InAppPurchaseState.Purchased:
					Fsm.Event(ProductPurchasedEvent);
					break;
				case InAppPurchaseState.Restored:
					Fsm.Event(ProductRestoredEvent);
					break;
				case InAppPurchaseState.Deferred:
					Fsm.Event(PurchaseDeferredEvent);
					break;
				case InAppPurchaseState.Failed:
					Fsm.Event(PurchaseFailedEvent);
					break;
			}

		}
	}
}

